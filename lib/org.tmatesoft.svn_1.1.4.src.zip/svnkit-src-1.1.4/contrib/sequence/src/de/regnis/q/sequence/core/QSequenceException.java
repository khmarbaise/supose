package de.regnis.q.sequence.core;

/**
 * @author Marc Strapetz
 */
public class QSequenceException extends Exception {

	// Setup ==================================================================

	public QSequenceException() {
	}

	public QSequenceException(Throwable cause) {
		super(cause);
	}
}